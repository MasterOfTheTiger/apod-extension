# apod-extension
Web extension to show the latest Astronomy Picture of the Day

## What I have done
I have completely changed the extension, the only thing that is the same is the icons. Here are some of the things I have done:

- Sorting through images
- Manually entering dates
- W3.css
- Footer

## Contributing
If you want to help, please do. I don't know how to use GitHub very well. So it would be great.

## Added Since 1.3
These are things that I have uploaded since I released version 1.3.
- Added APOD Twitter link to popup.html footer
- Added sharing on Facebook support
- Changed the way the Twitter sharing function works
- Changed sharing from popup to dropdown menu
- Fixed sharing not displaying when image date entered manually
